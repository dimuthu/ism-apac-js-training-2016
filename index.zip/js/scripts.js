$(function(){
  $('#flip-slider').flipSlider({delay: 200, offset: 100, easein: 'swing'});
});